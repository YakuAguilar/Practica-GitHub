#programa que calcule dos operandos con los 7 operadores vistos en clase. ¿Cómo puedes forzar que el resultado de la división tenga 2 decimales?
var1=int(input("introduce un número:"))
var2=int(input("introduce otro número:"))
#suma= +
total1=var1+var2
#resta= -
total2=var1-var2
#multiplicacion= *
total3=var1*var2
#division= /
total4=var1/var2
#potencia=**
total5=var1**var2
#división con resultado de número entero=//
total6=var1//var2
#modulo=%
total7=var1%var2
print(f"la suma es:",total1)
print(f"la resta es:", total2)
print(f"la multiplicación es:", total3)
resultado_redondeado = round(total4,2)
print(f"la división es:",resultado_redondeado)
#o total4=round(total4,2) despues de poner que total4 es una division
print(f"la potencia es:", total5)
print(f"la división con resultado de número entero es:", total6)
print(f"el modulo entre operadores es:", total7)