#A partir del código anterior, realiza una versión para números con decimales
var1=float(input("introduce un numero entero "))
var2=float(input("introduce un numero entero "))
total=var1+var2
print(f"la suma de los 2 valores es {total}")