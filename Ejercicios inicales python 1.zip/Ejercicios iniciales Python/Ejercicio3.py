#Programa que pida dos números enteros y realice la suma correspondiente
var1=int(input("introduce un numero entero "))
var2=int(input("introduce un numero entero "))
total=var1+var2
print(f"la suma de los 2 valores es {total}")