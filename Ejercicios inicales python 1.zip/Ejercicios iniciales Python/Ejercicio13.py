# Realiza un programa que, a partir introducir el lado de un cubo, presente por pantalla el área y para calcular el volumen utiliza el operador de exponente.
var1=float(input(f"introduce la medida de un lado "))
print(f"el area es {6*(var1**2)}")
print(f"el volumen es {var1**3}")