#Programa que muestre por pantalla la frase “hello world”
print ("hello world")