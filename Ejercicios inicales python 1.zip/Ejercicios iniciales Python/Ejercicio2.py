# Programa que introduzca por teclado tres tipos de variables y se muestren por pantalla en el siguiente orden: número entero, texto y número decimal.
var1=int(input("introduce un valor entero "))
var2=(input("introduce una letra "))
var3=float(input("introduce un valor decima "))
print(f"los valores introducidos son {var1}, {var2}, {var3}.")