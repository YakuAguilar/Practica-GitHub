#Realiza un programa que introduciendo el valor del lado de un cuadrado nos devuelva por pantalla en el área y el perímetro.
var1=int(input("introduce la medida de un lado del cuadrado "))
print(f"el area es {var1*var1}")
print(f"el perimetro es {var1*4}")

