#Programa que pida cinco palabras y muestre una frase con las cinco. Modifica el código para que entre palabra y palabra haya una coma.
var1=(input("introduce una palabra "))
var2=(input("introduce otro palabra "))
var3=(input("introduce otro palabra "))
var4=(input("introduce otro palabra "))
var5=(input("introduce otro palabra "))
print(F"{var1}, {var2}, {var3}, {var4}, {var5}.")