# A partir del programa 5. Haz que se muestre por pantalla también la frase en el orden inverso en que se han introducido las palabras.
var1=(input("introduce una palabra "))
var2=(input("introduce otro palabra "))
var3=(input("introduce otro palabra "))
var4=(input("introduce otro palabra "))
var5=(input("introduce otro palabra "))
print(f"{var1}, {var2}, {var3}, {var4}, {var5}.")
print(f"{var5}, {var4}, {var3}, {var2}, {var1}.")