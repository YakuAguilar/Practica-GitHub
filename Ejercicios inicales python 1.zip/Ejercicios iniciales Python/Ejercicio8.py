#programa que pida un número de horas y muestre por pantalla los minutos y segundos
var1=float(input("introduce catidad de horas "))
totalminutos=var1*60
totalsegundos=var1*3600
print(f"{var1} son {totalminutos} minutos y {totalsegundos} segundos")